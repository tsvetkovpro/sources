<?
$sSectionName="fancybox";
?>