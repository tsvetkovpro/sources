# ArbeitBot Landing
Landing page for [@arbeit_bot](https://telegram.me/arbeit_bot) (Telegram bot)

#Want to contribute?
Just fork and make a pull request – as easy as that ;) If you find an issue – create an issue ;)

#Where to seek help?
Bug our group on Telegram: [@borodutcher](https://telegram.me/borodutcher).
