<?php

class PrefixCollision_A_B_Bar
{
    public static $loaded = true;
}
