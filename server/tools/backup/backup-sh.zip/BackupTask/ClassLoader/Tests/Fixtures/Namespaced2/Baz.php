<?php

namespace Namespaced2;

class Baz
{
    public static $loaded = true;
}
