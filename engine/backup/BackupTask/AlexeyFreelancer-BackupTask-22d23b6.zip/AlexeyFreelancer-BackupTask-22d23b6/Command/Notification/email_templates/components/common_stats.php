Started at: <?php echo date('Y-m-d H:i:s', $started_at) ?> 
Finished at: <?php echo date('Y-m-d H:i:s', $finished_at) ?> 
Total: <?php echo ($finished_at - $started_at) ?> sec.