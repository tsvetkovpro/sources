<?php

$a = new stdClass();
