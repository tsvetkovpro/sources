<?php

namespace ClassesWithParents;

interface GInterface
{
}
