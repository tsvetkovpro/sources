<?php

class Foo
{
}
