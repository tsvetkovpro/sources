<?php

class Apc_Pearlike_Foo
{
    public static $loaded = true;
}
