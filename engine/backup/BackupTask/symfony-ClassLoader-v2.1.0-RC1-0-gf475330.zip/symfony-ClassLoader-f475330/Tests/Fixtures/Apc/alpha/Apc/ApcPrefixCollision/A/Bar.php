<?php

class ApcPrefixCollision_A_Bar
{
    public static $loaded = true;
}
