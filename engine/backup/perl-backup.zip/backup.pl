#!/usr/bin/perl -sw
# v 0.3.1
use strict;
use warnings;
use Net::FTP;
use DBI;
use POSIX;
use MIME::Lite;
use Cwd qw(abs_path);

use vars qw( $rotate $backup $data $mysql $restore $data2 $list);

my $errors = '';

BEGIN {
   $SIG{__DIE__} = sub {
		$errors .= $_[0];
   };
   $SIG{__WARN__} = sub{
    #print $_[0]; 
   };
}
END {
	if ($errors){
		send_email($errors);
	}
}

(my $path) = abs_path($0) =~ /(.*[\/\\])/;

	do "$path/config.cf" or die $!;

our $FTP_IP = $FTP_IP;
our $FTP_USER = $FTP_USER;
our $FTP_PASSWD = $FTP_PASSWD;
our $DB_HOST = $DB_HOST;
our $DB_USER = $DB_USER;
our $DB_PASSWD = $DB_PASSWD;
our $mysqldump = $mysqldump;
our $dupl = $dupl;
our $TMP = $TMP;
our $email = $email;
our $lftp = $lftp;

my $date = (strftime "%Y-%m-%d", localtime);
my $ftp;
my $databases;
my $shell;

my $export="TMPDIR=$TMP; PATH=\"/sbin:/bin:/usr/sbin:/usr/bin:/usr/local/sbin:/usr/local/bin:/root/bin\";";

sub send_email {
	my $msg = MIME::Lite->new (
#		From => 'Backup Script <$email>',
		To => $email,
		Subject => 'Во время выполнения бэкапа произошла ошибка\n',
		Data => "$_[0]"
		);
	$msg->send;
}


if (!-d "$TMP") {
	mkdir($TMP) or die "Не могу создать директорию $TMP. $!\n";
}

if(!-x $mysqldump){
	die $!;
}

if(!-x $dupl){
	die $!;
}

if(!-x $lftp){
	die $!;
}

sub FTP_connect {
	$ftp = Net::FTP->new("$FTP_IP", Debug => 0) or die "Невозможно подключиться к FTP $FTP_IP. $!";
	$ftp->login("$FTP_USER","$FTP_PASSWD") or die "Ошибка: ", $ftp->message;
	$ftp->binary;
}

sub Create_dir {
	FTP_connect();
	my @dir = ('data','mysql', 'data2', 'mysql2');
	foreach my $dir (@dir) {
		my @f = $ftp->dir("$dir");
		if(!@f) {
			$ftp->mkdir("$dir") or die "Невозможно создать папку. ", $ftp->message;
		}
	}
	$ftp->quit;
}

sub Put_FTP {
	FTP_connect();
	$ftp->put($_[0], $_[1]) or die "Невозможно закачать файл. ", $ftp->message;
	$ftp->quit;
}

sub Help {
	print "Скрипт отпимизирован для работы с FTP-серверами бэкапов на Majordomo.ru.
-backup
	-data Путь_до_каталога
		Пример (будет выполнено архивирование каталога /var/www/test):
		/root/bin/backup.pl -backup -data /var/www/test
	-mysql Имя_базы
		(Если базы данных не указаны - осуществляется резервное копирование всех баз. Можно указать несколько баз - через пробел)
		Пример (будет выполнено копирование баз mysql и test2):
		/root/bin/backup.pl -backup -mysql mysql test2
		Пример 2 (будет выполнено копирование всех баз):
		/root/bin/backup.pl -backup -mysql

-rotate
	Выполняет ротацию файлов на FTP-сервере.
-restore
	-data время (формат - 3D (3 дня)) Директория_для восстановления Директория_куда_восстановить (если не указано - в текущую директорию).
		Каталог куда происходит восстановление должен быть пустым!
		Пример (восстановит каталог /var/www/test в текущую директорию):
		/root/bin/backup.pl -restore -data 6D /var/www/test .
		Пример 2 (восстановит каталог /var/www/test в директорию /var/www/test2):
		/root/bin/backup.pl -restore -data 6D /var/www/test /var/www/test2
	-data2
		См. пример \"-restore -data\", используется для разворачивания отротированных бэкапов из директории data2 на FTP.
	-mysql Архив_дампа_на_FTP Имя_базы_в_которую_восстановить
		Пример (база_на_фтп - данные взяты из -list -mysql):
		/root/bin/backup.pl -restore -mysql /mysql/test-2011-06-30.gz test
-list
	-data	Путь_до_каталога_архивируемых_данных
		Выводит листинг хранящихся на FTP цепочек duplicity
		Пример (в случае если в задании был указан каталог \"/var/www/user/\"):
		/root/bin/backup.pl -list -data /var/www/user/
	-data2
		Путь до каталога с архивируемыми данными на FTP-сервере, см. пример к \"-list -data\".
	-mysql
		Выводит список дампов баз данных MySQL на FTP-сервере.
";
}

if ($rotate){
	Create_dir();
	FTP_connect();
	$shell = "$lftp -u $FTP_USER,$FTP_PASSWD $FTP_IP";
	eval {system("$shell -e \"rm -rf data2;exit\" >/dev/null") == 0 or die $!};
	if ($?!=0){
	   	die "Error in \"rm -rf data2\" Error:", $!;
	}
	eval {system("$shell -e \"rm -rf mysql2;exit\" >/dev/null") == 0 or die $!};
	if ($?!=0){
	   	die "Error in \"rm -rf mysql2\" Error:", $!;
	}
	$ftp->rename("data", "data2") or die "Невозможно переименовать ", $ftp->message;
	$ftp->rename("mysql", "mysql2") or die "Невозможно переименовать ", $ftp->message;
	$ftp->quit;
	rename("/var/log/backup.log", "/var/log/backup2.log");
	Create_dir();
	exit;
}

if ($backup){
	Create_dir();
# Бэкап data
	if ($data) {
		if (!$ARGV[0]){
		die "Для резервного копирования файлов необходимо указать, как минимум, путь до каталога.\n";
		}
		print "======== Start backup data at $date=======\n";
		my $homedir = $ARGV[0];
		my $exclude = $ARGV[1];
		if ($ARGV[1]){
			my $command = "$export $dupl --no-encryption --tempdir $TMP --exclude  $exclude $homedir ftp://$FTP_USER:$FTP_PASSWD\@$FTP_IP/data$homedir";
			system($command) == 0 or die $!;
		}
		else {
			my $command = "$export $dupl --no-encryption --tempdir $TMP $homedir ftp://$FTP_USER:$FTP_PASSWD\@$FTP_IP/data$homedir";
			system($command) == 0 or die $!;
		}
		print "Бэкап файлов выполнен успешно.\n";
		print "======== End backup data at $date=========\n";
		exit;	
	}
	
# Бэкап MySQL
	if ($mysql){		
	    my $dbh = DBI->connect("DBI:mysql:host=$DB_HOST", $DB_USER, $DB_PASSWD) or die "Невозможно подключиться к MySQL. $DBI::errstr \n";            
		print "======== Start backup mysql at $date=======\n";
		sub Backup_MySQL {
			if ($databases == 'information_schema'){
			next;
			}
			my $local_mysql = "$TMP/$_[0]-$date";
			my $remote_mysql = "mysql/$_[0]-$date.gz";
			print "Выполняю бэкап базы $_[0]\n";
		    eval {
		    	system("$mysqldump -a -l -u$DB_USER -p$DB_PASSWD $_[0] > $local_mysql") == 0 or die ("Не удалось выполнить дамп базы данных 
$_[0], подробности в лог-файле.\n");
		    };
		    if ($?!=0){
		    	print "Не удалось выполнить дамп базы данных $_[0], подробности в лог-файле.\n";
		    	next;
		    }
		    system("$export gzip -9 $local_mysql") == 0 or die;
			Put_FTP("$local_mysql.gz", $remote_mysql);
			unlink "$local_mysql.gz";
		}
		my @DATABASES = @ARGV;
		if(@DATABASES) {
			foreach $databases (@DATABASES) {
				Backup_MySQL($databases);
			}
			$dbh->disconnect;
		}
		else {
			my $sth = $dbh->prepare("SHOW DATABASES");
			$sth->execute() or die "Ошибка при выполнении запроса.\n", $sth->errstr;;
			while ($databases = $sth->fetchrow_array ) {
	    		Backup_MySQL($databases);
	  		}
	  		$dbh->disconnect;
		}
		print "Бэкап mysql выполнен успешно.\n";
		print "======== End backup mysql $date=========\n";
		exit;
	}
}

if ($restore){
	if ($data){
		my $dupl_date = $ARGV[0];
		my $source_url = $ARGV[1];
		my $target_directory = $ARGV[2];
		if (!$dupl_date || !$source_url || !$target_directory){
			die "Для восстановления файлов необходимо указать, как минимум, количество дней и путь до каталога.\n";
		}
		my $command = "$export $dupl --no-encryption --no-print-statistics -t $dupl_date ftp://$FTP_USER:$FTP_PASSWD\@$FTP_IP/data/$source_url $target_directory";
		system($command) == 0 or die $!;
		exit;
	}
	if ($data2){
		my $dupl_date = $ARGV[0];
		my $source_url = $ARGV[1];
		my $target_directory = $ARGV[2];
		if (!$dupl_date || !$source_url || !$target_directory){
			die "Для восстановления файлов необходимо указать, как минимум, количество дней и путь до каталога.\n";
		}
		my $command = "$export $dupl --no-encryption --no-print-statistics -t $dupl_date ftp://$FTP_USER:$FTP_PASSWD\@$FTP_IP/data2/$source_url $target_directory";
		system($command) == 0 or die $!;
		exit;
	}
	if ($mysql){
		my $mysql_source = $ARGV[0];
		my $mysql_target = $ARGV[1];
		if (!$mysql_source || !$mysql_target){
		print "Необходимо указать путь до дампа на ftp-сервере и базу данных.\n";
		exit;
		}
		FTP_connect();
		eval{
			$ftp->get($mysql_source, "$TMP/$mysql_target.gz");
			$ftp->quit;
		};
		if ($?!=0){
	   		die $!, $ftp->message;
		}
		if(!-e "$TMP/$mysql_target.gz"){
			print "$mysql_source - такого дампа нет на ftp.\n";
			exit;
		}
		my $command = "$export zcat $TMP/$mysql_target.gz | mysql -u$DB_USER -p$DB_PASSWD $mysql_target";
		system($command) == 0 or print $!, exit;
		unlink "$TMP/$mysql_target.gz";
		print "База $mysql_source успешно восстановленна в базу данных $mysql_target.\n";
		exit;
	}	
}

if ($list){
	if ($data){
		my $source_url = $ARGV[0];
		my $target_directory = $ARGV[1];
		if (!$source_url){
			print "Необходимо указать путь до каталога на ftp-сервере.\n";
			exit;
			#Еще не готово.
			FTP_connect();
			my @dir = $ftp->ls("/data*/*") or die $!, $ftp->message;
				foreach my $dir (@dir){
				print $dir;
				print "\n";
			}
			$ftp->quit;	
		}
		my $command = "$export $dupl --no-encryption collection-status ftp://$FTP_USER:$FTP_PASSWD\@$FTP_IP/data/$source_url";
		system($command) == 0 or die $!;
		exit;
	}
	if ($data2){
		my $source_url = $ARGV[0];
		my $target_directory = $ARGV[1];
		if (!$source_url){
			print "Необходимо указать путь до каталога на ftp-сервере.\n";
			exit;
			#Еще не готово.
			FTP_connect();
			my @dir = $ftp->ls("/data*/*") or die $!, $ftp->message;
				foreach my $dir (@dir){
				print $dir;
				print "\n";
			}
			$ftp->quit;	
		}
		my $command = "$export $dupl --no-encryption collection-status ftp://$FTP_USER:$FTP_PASSWD\@$FTP_IP/data2/$source_url";
		system($command) == 0 or die $!;
		exit;
	}
	if ($mysql){
		FTP_connect();
		my @dir = $ftp->ls("/mysql*/*") or print "Нет MySQL дампов.\n";
		foreach my $dir (@dir){
			print $dir;
			print "\n";
		}
		$ftp->quit;
		exit;
	}	
}

Help();
