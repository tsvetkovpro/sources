<div class="alert alert-warning">
  Full guide coming in June 2014.
</div>

#### <i class="fa fa-magic text-danger"></i> Demo
<a class="jsbin-embed" href="http://jsbin.com/gedak/1/embed?output">Split Pane</a>
<script src="http://static.jsbin.com/js/embed.js"></script>

<hr>
#### <i class="fa fa-lightbulb-o text-danger"></i> Additional Resources

1. [jQuery Split Plane Plugin](https://github.com/shagstrom/split-pane)
