<div class="alert alert-warning">
  Full guide coming in June 2014.
</div>

<hr>
#### <i class="fa fa-lightbulb-o text-danger"></i> Additional Resources

1. [How to create a parallax scrolling website](http://ihatetomatoes.net/how-to-create-a-parallax-scrolling-website/)
2. [How to integrate simple Parallax with Bootstrap](http://untame.net/2013/04/how-to-integrate-simple-parallax-with-twitter-bootstrap)
3. [Bootstrap Scroller parallax template one page responsive wireframe](https://coderwall.com/p/mk4kea)
4. [Parallax.js](http://stolksdorf.github.io/Parallaxjs/)
5. [Parallax](https://github.com/wagerfield/parallax)
