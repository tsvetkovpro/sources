<div class="alert alert-warning">
  Full guide coming in May 2014.
</div>

Meanwhile, check out the source code for the project below: [client-side usage](https://github.com/sahat/csc322/blob/master/public/js/custom.js#L196)
and [server-side handling](https://github.com/sahat/csc322/blob/master/server.js#L474).
And here is a fully working [demo](http://csc322.herokuapp.com).

**Note:** That was my very first Node.js project with very little client-side
JavaScript experience from over 2 years ago. I do not recommend using it as a
learning resource.

![](images/frontend/intermediate/star-rating-plugin-1.png)

<hr>
#### <i class="fa fa-lightbulb-o text-danger"></i> Additional Resources

1. [jQuery Raty](http://wbotelhos.com/raty/)
