<img src="http://listjs.com/images/graphics/listjs-logo.png" height="150">

<div class="alert alert-warning">
  Full guide coming in May 2014.
</div>

Demo of a **sortable** and **filterable** table using [List.js](http://listjs.com/).
It works with tables that have pre-existing data defined in HTML.

<iframe width="100%" height="300" src="http://jsfiddle.net/sahat/sT9bX/embedded/result,html,js" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

