#### jQuery
[Infinite Scroll](http://www.infinite-scroll.com)

<h4 style="color: #b82834">Angular.js</h4>
[ngInfiniteScroll](http://binarymuse.github.io/ngInfiniteScroll)

<h4 style="color: #0071b5">Backbone.js</h4>
[backbone-pageable](https://github.com/backbone-paginator/backbone-pageable)

[Lightweight Infinite Scrolling using Twitter API](backbonetutorials.com/infinite-scrolling)

<h4 style="color: #FF851B">Ember.js</h4>
[Ember Infinite Scroll](https://github.com/bantic/ember-infinite-scroll)

<div class="alert alert-warning">
  Full guide coming in May 2014.
</div>

<hr>
#### <i class="fa fa-lightbulb-o text-danger"></i> Additional Resources

1. [10 Reasons Not To Use Infinite Scroll On Your Website](http://geeks.bizzabo.com/10-reasons-not-to-use-infinite-scroll-on-your-website)
