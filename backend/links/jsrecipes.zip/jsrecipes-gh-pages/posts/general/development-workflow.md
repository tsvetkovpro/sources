#### JavaScript Development Workflow of 2013 by Paul Irish

<div class="video-container">
  <iframe width="560" height="315" src="//www.youtube.com/embed/f7AU2Ozu8eo" frameborder="0" allowfullscreen></iframe>
</div>