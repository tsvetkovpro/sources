# fox-hover
CSS3 Hover Animation Pack

##Features
- Pure HTML5/CSS3. No jQuery
- 30+ Effects (no need to add any CSS file)
- Easy to Use and Customize
- Overlay Effects, Image Effects, Caption Effects

##How to use:
1. Download files
2. Run HTML-file in your browser
3. Push button "HTML" under the effect you want to use. Add this code to your page (with all custom classes, it's important).
4. Change the value of "src" attribute (<img> tag) to your picture name.
5. Push button "CSS" under the effect you want to use. Add this code to your CSS file.
