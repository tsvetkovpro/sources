xdescribe("UI Popup", function() {

  moduleTests({
    module  : 'popup',
    element : 'i.icon'
  });

});